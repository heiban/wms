/**
 * Created by wanghui on 16/6/4.
 */
define(["jquery"],function($){
    var serverApi={
        "ApiClientPassportLogin":"http://www.baidu.com"
    };
    function request(url,data,callback){
        alert(url);
        $.ajax( {
            url:url,data:data,type:'post',cache:false,dataType:'json',
            success:function(result) {
                callback(result);
            },
            error : function() {
                callback({error:1,result:"",message:"异常"})
            }
        });
    }
    return $.extend(serverApi,{
        request:request
    });
});