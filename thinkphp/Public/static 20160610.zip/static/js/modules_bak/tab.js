/**
 * Created by wanghui on 16/6/5.
 */
define(["jquery"],function($){
    function Tab(tab,view,index,active){
        $(document).ready(function () {
            $(tab).on("click",function(event){
                $(tab).removeClass(active);
                $(event.target).addClass(active);
                $(tab).each(function(index,item){
                    if(item==event.target){
                        $(view)[index].show();
                    }else{
                        $(view)[index].hide();
                    }
                });
            });
        });

    }
    return Tab;
});