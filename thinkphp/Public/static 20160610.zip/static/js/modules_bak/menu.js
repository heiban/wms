define(['underscore'],function(_){
    var tpl='<% _.each(data, function (item) { %><a class="item-list" href="#<%=item.module%>"><%=item.label%></a><% }); %>';
    function init(config){
        var menu = $(config['container']);
        menu.html(_.template(tpl)({data:config['list']}));
        menu.on("click",function(event){
            $(config['container']+" .item-list").removeClass("active");
            $(event.target).addClass("active");
        });
        $(config['container']+" .item-list").eq(config['defaultIndex']).addClass("active");
    }
    return {
        init: init
    };
})