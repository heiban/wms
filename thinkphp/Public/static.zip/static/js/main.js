/**
 * Created by wanghui on 16/6/2.
 */
(function (win) {
    //var baseUrl = document.getElementById('main').getAttribute('data-baseurl');
    var config = {
        baseUrl: "./js/modules/",           //依赖相对路径
        paths: {                    //如果某个前缀的依赖不是按照baseUrl拼接这么简单，就需要在这里指出
            jquery: '../libs/jquery.min',
            underscore: '../libs/underscore-min',
            backbone: '../libs/backbone-min'
        },
        shim: {                     //引入没有使用requirejs模块写法的类库。backbone依赖underscore
            'jquery': {
                exports: '$'
            },
            'underscore': {
                exports: '_'
            },
            'backbone': {
                deps: ['underscore','jquery'],
                exports: 'Backbone'
            }
        }
    };
    require.config(config);


    require(['nav','receipt'],function(Nav,receipt){
        var menuNav = new Nav({
            tabClass:'.list-menu .item-menu',viewClass:'.list-content .item-content',activeClass:'active',
            initModule:{
                "receiptModule":function(){
                    console.log("receiptModule");
                    var receiptDraftNav = new Nav({tabClass:'.list-tab .item-tab',viewClass:'.list-view .item-view',activeClass:'active',
                        initModule:{
                            "receiptDraftModule":function(){
                                console.log("receiptDraftModule");
                                receipt.initDraftModule();
                            },
                            "receiptActiveModule":function(){
                                console.log("receiptActiveModule");
                                receipt.initActiveModule();
                            }
                        }});
                    receiptDraftNav.index(0);
                },
                "invoiceModule":function(){console.log("invoiceModule")}
            }
        });
        menuNav.index(0);

    });


})(window);

/*
*require(['jquery'],function($){
 $('table').on("click",function(event){
 console.log(event.target.parentNode);
 $('#receiptModule tr').removeClass("active");
 var item = $(event.target.parentNode);
 item.addClass("active");
 var value = item.attr("node-data");
 console.log(value);

 });
 });
* */