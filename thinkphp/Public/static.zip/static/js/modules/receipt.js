/**
 * Created by wanghui on 16/6/5.
 */
define(['jquery','click','table','popup'],function($,Click,Table,Popup){
    /*initDraftModule*/
    var receiprDragtTable = new Table('#receiptDraftModule .table-receipt-draft .table',[
        {name:"申请单编号",param:"receipt_code"},
        {name:"创建时间",param:"receipt_createdate"},
        {name:"预报物流单号1",param:"receipt_dcode"},
        {name:"预报物流单号2",param:"receipt_dcode2"},
        {name:"申请单状态",param:"receipt_status"}
    ],"lineactive");
    var receiprIngoodTable = new Table('#receiptDialog .detail-receipt .table',[
        {name:"仓内编码",param:"ingoods_code"},
        {name:"商品名称",param:"sku_name"},
        {name:"商品条码",param:"sku_barcode"},
        {name:"入仓数量",param:"ingoods_num"},
        {name:"操作",param:"op-delete"}
    ],"lineactive");
    var receiptDraftOper = new Click('#receiptDraftModule .oper-receipt-draft');
    function initDraftModule(){
        receiprDragtTable.render([
            {
                receipt_code:"R0001020021",
                receipt_createdate:"20140302 12:22:21",
                receipt_dcode:"JJ009811032",
                receipt_dcode2:"JD1122330092",
                receipt_status:"已创建,未提交"
            },{
                receipt_code:"R0001020022",
                receipt_createdate:"20120302 19:22:21",
                receipt_dcode:"JJ009814432",
                receipt_dcode2:"JD11223220001",
                receipt_status:"已创建,未提交"
            }
        ]);
        receiptDraftOper.click({
            "create":function(){
                console.log("create");
                receiptIngoodPopup.show();
            },
            "refresh":function(){
                console.log("refresh");
            },
            "modify":function(){
                var index = receiprDragtTable.selectedIndex();
                var data = receiprDragtTable.selectedItem();
                console.log("modify:"+index+","+data);
            },
            "delete":function(){
                var index = receiprDragtTable.selectedIndex();
                console.log("delete:"+index);
                receiprDragtTable.deleteItem(index);
            },
            "apply":function(){
                var index = receiprDragtTable.selectedIndex();
                var data = receiprDragtTable.selectedItem();
                console.log("apply:"+index+","+data);
            }
        });

        var receiptIngoodPopup = new Popup({
            id:"#receiptDialog",
            title:"申请创建入仓单",
            cancelTitle:"放弃申请",
            sureTitle:"保存提交",
            width:"800",
            onSure:function(){
                var data = receiprIngoodTable.data();
                receiprIngoodTable.clear();
                return 1;
            },
            onInit:function(param){
                receiprIngoodTable.render([
                    {
                        ingoods_code:"IG0001021234",
                        sku_name:"商品名称1",
                        sku_barcode:"2001200220021",
                        ingoods_num:"1000",
                        "op-delete":"删除"
                    },{
                        ingoods_code:"IG0001022345",
                        sku_name:"商品名称2",
                        sku_barcode:"1001200220021",
                        ingoods_num:"30000",
                        "op-delete":"删除"

                    },{
                        ingoods_code:"IG0001022349",
                        sku_name:"商品名称3",
                        sku_barcode:"900099878720021",
                        ingoods_num:"2000",
                        "op-delete":"删除"
                    }
                ]);
                receiprIngoodTable.setOpCallback(function(index,code){
                    if(code =="op-delete") {
                        receiprIngoodTable.deleteItem(index);
                        receiprIngoodTable.render(receiprIngoodTable.data());
                    }
                });
                return 1;
            }
        });

    }
/*initActiveModule*/
    var receiprActiveTable = new Table('#receiptActiveModule .table-receipt-active .table',[
        {name:"申请单编号",param:"receipt_code"},
        {name:"创建时间",param:"receipt_createdate"},
        {name:"预报物流单号1",param:"receipt_dcode"},
        {name:"预报物流单号2",param:"receipt_dcode2"},
        {name:"申请单状态",param:"receipt_status"}
    ],"lineactive");
    function initActiveModule(){

        receiprActiveTable.render([
            {
                receipt_code:"R0001020021",
                receipt_createdate:"20140302 12:22:21",
                receipt_dcode:"JJ009811032",
                receipt_dcode2:"JD1122330092",
                receipt_status:"已创建,未提交"
            },{
                receipt_code:"R0001020022",
                receipt_createdate:"20120302 19:22:21",
                receipt_dcode:"JJ009814432",
                receipt_dcode2:"JD11223220001",
                receipt_status:"已创建,未提交"
            }
        ]);
    }

    return{
        initDraftModule:initDraftModule,
        initActiveModule:initActiveModule
    };
});