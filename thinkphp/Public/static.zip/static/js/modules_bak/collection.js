/**
 * Created by wanghui on 16/6/4.
 */
define(['jquery'],function($){
    function Collection(){
        var listData=[];
        this.init =  function(data){
            listData = data;
        };
        this.addItem = function(item){
            listData.push(item);
        };
        this.getItem =  function(index){
            return listData[index];
        };
        this.delItem =  function(index){
            listData.splice(index,1);
        };
        this.getList = function(){
            return listData;
        };
        this.count = function(){
            return listData.length;
        };
    }
    return Collection;
});