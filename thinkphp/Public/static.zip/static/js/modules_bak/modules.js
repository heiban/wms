define(['jquery'],function($){
    function init(container,module){
        if($(container+' #'+module).length>0){
            $(container+' .module').each(function(index,item){
                if($(item).attr('id')==module){
                    $(item).show();
                }else{
                    $(item).hide();
                }
            });
        }
    }
    return {
        init: init
    };
})