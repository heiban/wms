/**
 * Created by wanghui on 16/6/4.
 */
define(["jquery","underscore"],function($,_){
    function Table(id,colNames){
        var tableData,tableId,tableColNames;
        var opCallback=null;

        tableId = id;
        tableColNames = colNames;
        function initEvent(){
            var $lines = $(tableId+" tr[data-index]");
            $lines.on("click",function(event){
                var $line = $(event.currentTarget);
                var index = $line.attr("data-index");
                $lines.removeClass("active");$line.addClass("active");

            });
            if(opCallback)
                $(tableId+" span[data-index]").on("click",function(event){
                var $line = $(event.currentTarget);
                var index = $line.attr("data-index");
                opCallback && opCallback(index,$line.html());
            });
        }
        this.index=function(){
            $line = $(tableId+" tr[class='active']");
            if($line.length==1){
                return $line.attr("data-index");
            }else{
                return -1;
            }
        };
        this.render=function(data){
            tableData = data;
            var colTpl='<tr><% _.each(colNames,function(item){%><th><%=item.name%></th><%});%></tr>';
            var rowTpl='<tr data-index="<%=itemIndex%>">' +
                '<% _.each(colNames,function(item){' +
                'if(item.param.indexOf("op-")>-1){' +
                '%><td><span data-index="<%=itemIndex%>"><%=itemData[item.param]%></span></td><%' +
                '}else{' +
                '%><td><%=itemData[item.param]%></td><%}' +
                '});%>' +
                '</tr>';
            $(tableId).html('');
            $(tableId).append(_.template(colTpl)({colNames:tableColNames}));
            $(tableData).each(function(index,item){
                $(tableId).append(_.template(rowTpl)({colNames:tableColNames,itemData:item,itemIndex:index}));
            });
            initEvent();
        };
        this.reset=function(){
            $(tableId+" tr[data-index]").removeClass("active");
        };
        this.setOpCallback=function(callback){
            opCallback=callback;
        }
    }
    return Table;
});

;