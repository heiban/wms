/**
 * Created by wanghui on 16/6/2.
 */
(function (win) {
    //var baseUrl = document.getElementById('main').getAttribute('data-baseurl');
    var config = {
        baseUrl: "./js/modules/",           //依赖相对路径
        paths: {                    //如果某个前缀的依赖不是按照baseUrl拼接这么简单，就需要在这里指出
            jquery: '../libs/jquery.min',
            underscore: '../libs/underscore-min',
            backbone: '../libs/backbone-min'
        },
        shim: {                     //引入没有使用requirejs模块写法的类库。backbone依赖underscore
            'jquery': {
                exports: '$'
            },
            'underscore': {
                exports: '_'
            },
            'backbone': {
                deps: ['underscore','jquery'],
                exports: 'Backbone'
            }
        }
    };
    require.config(config);


    require(['menu'],function(menu){
        var config={
            container:".list-menu",
            defaultIndex:0,
            list:[
                {
                    label:"入仓管理",
                    module:"receipt"
                },
                {
                    label:"发货管理",
                    module:"invoice"
                }
            ]
        };
        menu.init(config);
    });

    require(['backbone','jquery','router'], function(Backbone){
        Backbone.history.start();
    });

})(window);

/*
*require(['jquery'],function($){
 $('table').on("click",function(event){
 console.log(event.target.parentNode);
 $('#receiptModule tr').removeClass("active");
 var item = $(event.target.parentNode);
 item.addClass("active");
 var value = item.attr("node-data");
 console.log(value);

 });
 });
* */